# Créditos e uso de imagens

As fotografias foram verificadas e baixadas do CDN do Pexels em 19/10/2026. Estão incluídas localmente para evitar URLs remotas quebradas. As pessoas fotografadas não são apresentadas como clientes, integrantes da equipe ou autoras dos depoimentos. O interior é uma referência visual, não o endereço de uma empresa real.

A [licença do Pexels](https://www.pexels.com/license/) permite uso pessoal e comercial e adaptações, sem atribuição obrigatória. Ela proíbe, entre outros usos, sugerir endosso das pessoas retratadas e revender cópias sem alteração como banco de imagens. Consulte os termos originais para o contexto da reutilização. A galeria desta demo identifica o conteúdo como fotografias de inspiração.

| Arquivo | Fotógrafo / fonte | Página da fotografia |
| --- | --- | --- |
| `hero.jpg` | Michelle Leman / Pexels | [Retrato com cachos](https://www.pexels.com/photo/calm-female-with-curly-hair-against-beige-background-6774277/) |
| `studio.jpg` | Max Vakhtbovych / Pexels | [Interior do salão](https://www.pexels.com/photo/beauty-salon-interior-design-7750099/) |
| `ondas.jpg` | Casa Rio Beauty Salon / Pexels | [Cabelos com ondas](https://www.pexels.com/photo/brunette-with-wavy-hair-in-a-salon-setting-38651013/) |
| `corte.jpg` | cottonbro studio / Pexels | [Cuidado no lavatório, foto 3993449](https://www.pexels.com/photo/3993449/) |
| `unhas.jpg` | Isabella Mendes / Pexels | [Aplicação de esmalte](https://www.pexels.com/photo/a-person-applying-a-nail-polish-12151232/) |
| `beleza.jpg` | Manuel Gamboa / Pexels | [Retrato com cabelos pretos](https://www.pexels.com/photo/portrait-of-woman-with-black-hair-20861525/) |

O nome de arquivo `corte.jpg` é apenas uma identificação de recurso; a imagem é de tratamento no lavatório, corretamente descrito no texto alternativo e na galeria.

Os downloads usam `https://images.pexels.com/photos/ID/pexels-photo-ID.jpeg` com parâmetros de compressão e largura. O projeto não usa o screenshot de referência como conteúdo do site.

Fontes: Cormorant Garamond e DM Sans, distribuídas pelo Fontsource sob SIL Open Font License. Ícones: Lucide, licença ISC. As licenças das fontes acompanham a pasta `licenses/`. As dependências mantêm suas licenças nos pacotes correspondentes.
