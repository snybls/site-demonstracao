import { mkdir, readFile, readdir, writeFile } from 'node:fs/promises'
import { Script } from 'node:vm'
import { build } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

// A second build for opening with file://. The deployment build in dist keeps
// its normal split assets, lazy images and module entry point.
const images = {}
for (const file of await readdir('public/images')) {
  if (!file.endsWith('.jpg')) continue
  images[file.slice(0, -4)] = `data:image/jpeg;base64,${(await readFile(`public/images/${file}`)).toString('base64')}`
}

const result = await build({
  configFile: false,
  plugins: [
    {
      name: 'portable-local-photographs',
      enforce: 'pre',
      transform(code, id) {
        if (!id.split('?')[0].endsWith('.tsx')) return
        return code
          .replace(/src=(["'])\/images\/([^"']+)\.jpg\1/g,
            (_, quote, name) => `src={window.__BELLA_DEMO_IMAGES__[${JSON.stringify(name)}]}`)
          .replace(/`\/images\/\$\{([^}]+)\}\.jpg`/g,
            (_, expression) => `window.__BELLA_DEMO_IMAGES__[${expression}]`)
      },
    },
    react(),
    tailwindcss(),
  ],
  define: { 'process.env.NODE_ENV': JSON.stringify('production') },
  logLevel: 'warn',
  build: {
    write: false,
    copyPublicDir: false,
    cssCodeSplit: false,
    assetsInlineLimit: Infinity,
    lib: { entry: 'src/main.tsx', name: 'BellaEssenceDemo', formats: ['iife'] },
  },
})

const output = (Array.isArray(result) ? result.flatMap(item => item.output) : result.output)
const javascript = output.filter(item => item.type === 'chunk').map(item => item.code).join('\n')
const css = output.filter(item => item.type === 'asset' && item.fileName.endsWith('.css')).map(item => item.source.toString()).join('\n')
if (/url\(\s*["']?(?!data:)[^)]*\.(?:woff2?|jpg)/i.test(css)) {
  throw new Error('A versão portátil ainda contém uma fonte ou imagem externa.')
}
if (javascript.includes('/images/')) throw new Error('Uma imagem não foi incorporada na versão portátil.')

const favicon = `data:image/svg+xml;base64,${(await readFile('public/favicon.svg')).toString('base64')}`
let html = await readFile('dist/index.html', 'utf8')
html = html
  .replace(/<script\b[^>]*data-local-preview[^>]*>[\s\S]*?<\/script>/g, '')
  .replace(/<script\b[^>]*type="module"[^>]*>[\s\S]*?<\/script>/g, '')
  .replace(/<link\b[^>]*rel="stylesheet"[^>]*>/g, '')
  .replace(/href="\/favicon\.svg"/, `href="${favicon}"`)
  .replace('</head>', () => `<style>${css}</style>\n</head>`)
  .replace('</body>', () => `<script>window.__BELLA_DEMO_IMAGES__=${JSON.stringify(images)};</script>\n<script>${javascript.replace(/<\/script/gi, '<\\/script')}</script>\n</body>`)

// Check the actual inline scripts after HTML insertion, including replacement
// characters present in compiled React code (such as "$&").
for (const match of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/g)) {
  if (!match[1].includes('application/ld+json')) new Script(match[2])
}

for (const directory of ['demo', 'dist/demo']) {
  await mkdir(directory, { recursive: true })
  await writeFile(`${directory}/index.html`, html)
}
console.log('Demonstração portátil: demo/index.html (React, fotos, fontes e estilos incorporados).')
