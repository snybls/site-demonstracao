import { readFile, writeFile } from "node:fs/promises";
import { loadEnv } from "vite";

const business = JSON.parse(
  await readFile(
    new URL("../src/config/business.json", import.meta.url),
    "utf8",
  ),
);
const env = loadEnv("production", process.cwd(), "VITE_");
const rawUrl =
  process.env.VITE_SITE_URL || env.VITE_SITE_URL || business.seo.siteUrl;
let siteUrl = "";
if (rawUrl) {
  const parsed = new URL(rawUrl);
  if (parsed.protocol !== "https:")
    throw new Error("O domínio público deve usar https://.");
  siteUrl = parsed.origin;
}
const escape = (value) =>
  value.replace(
    /[&<>"']/g,
    (ch) =>
      ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&apos;",
      })[ch],
  );
let html = await readFile("dist/index.html", "utf8");
html = html.replace(
  /<title>.*?<\/title>/,
  `<title>${escape(business.seo.title)}</title>`,
);
html = html.replace(
  /(<meta name="description" content=")[^"]*("\s*\/>)/,
  `$1${escape(business.seo.description)}$2`,
);
html = html.replace(
  /(<meta property="og:title" content=")[^"]*("\s*\/>)/,
  `$1${escape(business.seo.title)}$2`,
);
html = html.replace(
  /(<meta property="og:description" content=")[^"]*("\s*\/>)/,
  `$1${escape(business.seo.description)}$2`,
);
const indexable = !!siteUrl && business.seo.indexable && !business.demo;
html = html.replace(
  /<meta name="robots"[^>]*>/,
  `<meta name="robots" content="${indexable ? "index, follow" : "noindex, nofollow"}" />`,
);
let extras = "";
if (siteUrl) {
  extras += `<link rel="canonical" href="${escape(siteUrl)}/" />\n<meta property="og:url" content="${escape(siteUrl)}/" />\n<meta property="og:image" content="${escape(siteUrl)}/images/hero.jpg" />\n<meta property="og:image:alt" content="Retrato editorial: beleza natural e cachos" />`;
  const data = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: business.name,
    url: `${siteUrl}/`,
    inLanguage: "pt-BR",
    description: business.seo.description,
  };
  extras += `\n<script type="application/ld+json">${JSON.stringify(data).replace(/</g, "\\u003c")}</script>`;
}
html = html.replace("</head>", `${extras}\n</head>`);
await writeFile("dist/index.html", html);
await writeFile(
  "dist/robots.txt",
  `User-agent: *\n${indexable ? "Allow: /" : "Disallow: /"}\n${siteUrl ? `Sitemap: ${siteUrl}/sitemap.xml\n` : ""}`,
);
await writeFile(
  "dist/sitemap.xml",
  `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${siteUrl ? `\n  <url><loc>${escape(siteUrl)}/</loc></url>\n` : ""}</urlset>\n`,
);
console.log(
  `SEO: ${siteUrl || "sem domínio configurado"} · indexação ${indexable ? "ativa" : "desativada (demonstração)"}`,
);
