# Bella Essence Studio

Website demonstrativo de um salão fictício em Fortaleza, em português brasileiro. Visual editorial em marfim, rosé e champagne, fotografias locais e fontes hospedadas no próprio projeto.

## Começar em 1 minuto

**Para apenas visualizar:** dê dois cliques em `index.html` na pasta principal. Ele abre automaticamente `demo/index.html`, uma versão completa com fotos, fontes, estilos e React incorporados, que funciona sem servidor e sem instalação. Você também pode abrir `demo/index.html` diretamente.

**Para editar o projeto React:**

Requisitos: Node.js 22.12 ou superior e npm. Na pasta deste README:

```bash
npm ci
npm run dev
```

Abra o endereço Local informado pelo Vite, normalmente `http://127.0.0.1:5173`. Para encerrar, pressione Ctrl+C no terminal. No Windows, se o PowerShell bloquear scripts, use `npm.cmd` no lugar de `npm`.

```bash
npm run check    # Validação de TypeScript
npm run build    # TypeScript + build de produção + metadados e sitemap
npm run preview  # Conferir o build em http://127.0.0.1:4173
```

O build para hospedagem está em `dist/`. Use `npm run preview` para conferir essa versão por HTTP. Ao abrir `dist/index.html` por dois cliques, ele também encaminha para sua cópia portátil em `dist/demo/index.html`. O comando `npm run build` atualiza as versões de hospedagem e de demonstração portátil.

O navegador não executa arquivos TypeScript/TSX diretamente. Por isso, a abertura local usa a demonstração já compilada. Após editar o código ou a configuração, execute `npm run build` para atualizar essa demonstração; durante a edição, `npm run dev` mostra as mudanças automaticamente.

## O que está incluído

- React, Vite, TypeScript, Tailwind CSS 4, Lucide React e Framer Motion.
- Navegação fixa com indicação da seção e menu para celular.
- Hero, apresentação, seis serviços, filtros, galeria com ampliação, depoimentos, chamada de agendamento, contato e rodapé.
- Diálogos nativos com foco contido, fechamento por Escape e retorno ao botão que os abriu.
- Galeria com botões anterior/próximo e setas do teclado.
- Animações discretas que respeitam a preferência por movimento reduzido.
- Imagens com dimensões reservadas, prioridade no hero e carregamento tardio nas demais.
- Fotografias e fontes locais: nenhum pedido a Google Fonts, Pexels ou Maps ao visitar esta demonstração.
- Build estático com configuração para Netlify e fallback de SPA.

## Configurar para outro salão

O arquivo principal é `src/config/business.json`:

| Campo | Uso |
| --- | --- |
| `name` | Nome do negócio e marca principal |
| `city`, `state`, `address` | Dados de localização |
| `whatsapp` | Número autorizado com país e DDD, somente dígitos; vazio nesta demo |
| `instagram` | URL HTTPS do perfil autorizado; vazio nesta demo |
| `email` | E-mail real; vazio oculta o item |
| `mapEmbedUrl` | URL de incorporação do Google Maps, obtida do endereço real |
| `hours` | Dias e horários de atendimento |
| `services` | Nomes, descrições, categorias, ícones e preços numéricos em reais |
| `demo` | `true` mantém todos os agendamentos em modo demonstrativo |
| `seo` | Título, descrição, domínio e permissão de indexação |

Todos os botões de WhatsApp usam a função `bookingUrl` de `src/config/business.ts`. Um link real só é criado quando `demo` for `false` **e** houver um número brasileiro com `55`, DDD e 8 ou 9 dígitos. O serviço escolhido é incluído na mensagem sugerida, que o visitante ainda precisará enviar no WhatsApp. Nunca preencha um número aleatório.

Categorias usadas pelos filtros: `Cabelos` e `Unhas & beleza`. Ícones disponíveis: `scissors`, `wind`, `palette`, `droplets`, `flower`, `sparkles`. Para acrescentar categorias ou ícones, ajuste as listas de `src/sections/Services.tsx`.

Personalize os textos editoriais em `src/sections/`, a marca em `src/components/Brand.tsx` e as cores e espaçamentos em `src/styles/index.css`. Substitua as fotos em `public/images/` por imagens autorizadas e atualize os textos alternativos e dimensões. Confira `CREDITOS.md` antes de reutilizar imagens.

Ao adaptar para um negócio real, revise as menções editoriais ao nome, a cidade e os avisos demonstrativos dos componentes. Os avisos estão intencionalmente visíveis nesta entrega. Substitua depoimentos ilustrativos apenas por avaliações reais autorizadas; não os transforme em avaliações supostamente verificadas.

## Demonstração honesta

Esta entrega não tem pagamentos, autenticação, banco de dados, cadastro nem backend. Nenhum formulário coleta dados. Os botões de agendamento abrem uma explicação e não enviam mensagens nem criam reservas. Instagram e mapa são placeholders; não apontam para negócios de terceiros. Horários, preços e depoimentos são exemplos fictícios. A galeria é de inspiração, identificada na página, e não constitui portfólio do salão.

## SEO e domínio

O HTML entregue contém título, descrição, idioma, Open Graph e metadados de robôs. Sem domínio configurado, não há canonical nem URL de produção inventada. `sitemap.xml` permanece um XML válido, sem URLs; `robots.txt` bloqueia indexação nesta demonstração.

Quando houver um domínio real, defina `VITE_SITE_URL` no ambiente de build da Netlify, ou `seo.siteUrl` no JSON. Use a origem HTTPS completa, sem caminho. A variável de ambiente tem prioridade. O build então gera canonical, `og:url`, `og:image`, sitemap com a URL principal e dados estruturados `WebSite`, sem endereço inventado ou avaliações fabricadas.

Para permitir indexação de um negócio real, configure o domínio, altere `demo` para `false` e `seo.indexable` para `true`, revise o conteúdo e gere novo build. O modo de demonstração permanece bloqueado mesmo com domínio configurado. Alterações nas metatags do JSON entram no build de produção; o dev server usa as tags iniciais de `index.html`.

## Publicar na Netlify

Nenhuma publicação foi realizada nesta entrega.

Após autorização para publicar, escolha uma opção:

1. **Repositório Git:** envie o projeto a um repositório de sua escolha e importe-o na Netlify. Se o projeto estiver dentro de outra pasta no repositório, configure essa pasta como Base directory. O arquivo `netlify.toml` já especifica `npm run build`, pasta `dist` e Node 22.
2. **Upload manual:** execute `npm ci` e `npm run build`, depois envie somente o conteúdo de `dist/` para o deploy manual da Netlify. Essa alternativa não executa o build automaticamente. O arquivo `dist/_redirects` acompanha o build para a navegação SPA.

Confira o site no endereço retornado pela Netlify antes de divulgar. Nunca envie `node_modules/`; o lockfile fixa as versões instaladas.

### Conectar um domínio .com.br

Depois que o titular tiver um domínio e autorizar a configuração:

1. No projeto da Netlify, abra **Domain management → Production domains** e adicione o domínio do titular.
2. Selecione a verificação pendente de DNS e copie os registros exatos apresentados para aquele projeto.
3. No Registro.br, selecione o domínio e edite a zona DNS para aplicar os registros informados pela Netlify. Para `www`, use o CNAME indicado; para a raiz, siga os registros exibidos na configuração do projeto. Não use IPs copiados de exemplos antigos.
4. Como alternativa, use Netlify DNS e configure no Registro.br os servidores DNS que a Netlify fornecer. Preserve os registros de e-mail e outros serviços ao migrar o DNS.
5. Aguarde a validação DNS e a emissão do certificado HTTPS. Configure o domínio principal e confirme os redirecionamentos entre raiz e `www`.
6. Defina `VITE_SITE_URL` com o domínio principal HTTPS e publique um novo build para atualizar canonical e sitemap. Ao lançar um negócio real, revise também as flags de demonstração e indexação descritas acima.

Fontes oficiais: [Adicionar domínio na Netlify](https://docs.netlify.com/manage/domains/manage-domains/assign-a-domain-to-your-site-app/), [Configurar DNS externo](https://docs.netlify.com/manage/domains/configure-domains/configure-external-dns/) e [Tutoriais do Registro.br](https://www.registro.br/ajuda/tutoriais-administrativos/).

## Estrutura

```text
src/
  components/   # Marca, navegação, botões, diálogos e animação
  config/       # Configuração editável e lógica dos contatos
  sections/     # Conteúdo da página
  styles/       # Identidade visual e responsividade
  App.tsx
  main.tsx
public/
  images/       # Fotografias locais
  favicon.svg
  robots.txt
  sitemap.xml
  _redirects
scripts/seo.mjs # Geração de SEO no build
netlify.toml
```

Veja `VERIFICACAO.md` para o resultado dos testes da entrega.
