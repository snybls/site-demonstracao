import {
  MapPin,
  Clock3,
  Instagram,
  ArrowUpRight,
  Mail,
  MessageCircle,
} from "lucide-react";
import { business } from "../config/business";
import {
  BookingButton,
  InstagramButton,
  WhatsAppMark,
} from "../components/Booking";
import { Emblem } from "../components/Brand";
import Reveal from "../components/Reveal";

export function BookingSection() {
  return (
    <section className="booking-section" aria-labelledby="booking-title">
      <Reveal className="container booking-content">
        <div>
          <p className="eyebrow">PERMITA-SE ESSE MOMENTO</p>
          <h2 id="booking-title">
            Sua próxima experiência
            <br />
            de beleza <em>começa aqui.</em>
          </h2>
          <p>Um novo visual. Uma pausa na rotina. Um cuidado só seu.</p>
        </div>
        <div className="booking-action">
          <BookingButton className="button button-cream" icon={false}>
            <WhatsAppMark /> Agende pelo WhatsApp <ArrowUpRight size={17} />
          </BookingButton>
          <small>Modo demonstração · sem reservas reais</small>
        </div>
        <Emblem className="booking-emblem" />
      </Reveal>
    </section>
  );
}
export default function Contact() {
  return (
    <section
      id="contato"
      className="section contact-section container"
      aria-labelledby="contact-title"
    >
      <Reveal className="contact-copy">
        <p className="eyebrow">VAMOS NOS ENCONTRAR</p>
        <h2 id="contact-title">
          Seu refúgio de beleza,
          <br />
          em <em>Fortaleza.</em>
        </h2>
        <p className="contact-intro">
          Um espaço para cuidar de você com a leveza
          <br className="hidden sm:block" /> e o acolhimento que a nossa cidade
          inspira.
        </p>
        <div className="contact-details">
          <div>
            <MapPin size={21} strokeWidth={1.3} />
            <div>
              <h3>Onde estamos</h3>
              <p>{business.address}</p>
              <small>Localização ilustrativa · endereço a definir</small>
            </div>
          </div>
          <div>
            <Clock3 size={21} strokeWidth={1.3} />
            <div>
              <h3>Horário de funcionamento</h3>
              <dl>
                {business.hours.map((hour) => (
                  <div key={hour.days}>
                    <dt>{hour.days}</dt>
                    <dd>{hour.time}</dd>
                  </div>
                ))}
              </dl>
              <small>Horários demonstrativos</small>
            </div>
          </div>
          <div>
            <Instagram size={21} strokeWidth={1.3} />
            <div>
              <h3>Acompanhe o studio</h3>
              <InstagramButton>
                {business.instagram
                  ? "Visitar Instagram"
                  : "Instagram · em breve"}{" "}
                <ArrowUpRight size={14} />
              </InstagramButton>
            </div>
          </div>
          <div>
            <MessageCircle size={21} strokeWidth={1.3} />
            <div>
              <h3>Agende seu momento</h3>
              <BookingButton className="text-link">
                WhatsApp · demonstrativo
              </BookingButton>
              <small>Número de atendimento ainda não configurado</small>
            </div>
          </div>
          {business.email && (
            <div>
              <Mail size={21} />
              <div>
                <h3>Fale com a gente</h3>
                <a href={`mailto:${business.email}`}>{business.email}</a>
              </div>
            </div>
          )}
        </div>
      </Reveal>
      <Reveal className="map-placeholder">
        {business.mapEmbedUrl ? (
          <iframe
            title={`Localização de ${business.name}`}
            src={business.mapEmbedUrl}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        ) : (
          <>
            <div className="map-grid" aria-hidden="true">
              <span className="map-road road-one" />
              <span className="map-road road-two" />
              <span className="map-road road-three" />
              <span className="map-coast" />
            </div>
            <div className="map-card">
              <span className="map-pin">
                <MapPin size={25} strokeWidth={1.2} />
              </span>
              <span className="eyebrow">UM CANTINHO PARA VOCÊ</span>
              <h3>Fortaleza, CE</h3>
              <p>Nosso futuro ponto de encontro.</p>
              <span className="map-badge">MAPA ILUSTRATIVO</span>
            </div>
            <p className="map-note">
              Espaço reservado para integração com Google Maps.
              <br />
              Nenhum endereço real está indicado nesta demonstração.
            </p>
          </>
        )}
      </Reveal>
    </section>
  );
}
