import { ArrowDown, ArrowUpRight, Leaf, Heart, Sparkles } from "lucide-react";
import { BookingButton, WhatsAppMark } from "../components/Booking";
import Reveal from "../components/Reveal";

export default function Hero() {
  return (
    <>
      <section id="inicio" className="hero" aria-labelledby="hero-title">
        <div className="hero-content">
          <Reveal>
            <p className="eyebrow">
              <span className="small-line" /> SEU TEMPO. SUA BELEZA. SUA
              ESSÊNCIA.
            </p>
            <h1 id="hero-title">
              Realce sua beleza.
              <br />
              <em>
                Celebre sua
                <br className="desktop-break" /> essência.
              </em>
            </h1>
            <p className="hero-description">
              Um espaço dedicado ao seu bem-estar, autoestima e beleza, com
              experiências pensadas especialmente para você.
            </p>
            <div className="hero-actions">
              <a href="#servicos" className="button button-primary">
                Conheça nossos serviços <ArrowUpRight size={17} />
              </a>
              <BookingButton className="button button-text" icon={false}>
                <WhatsAppMark /> Agende pelo WhatsApp
              </BookingButton>
            </div>
            <p className="hero-demo">
              Agendamento ilustrativo · site demonstrativo
            </p>
            <a href="#sobre" className="discover">
              <span className="circle-arrow">
                <ArrowDown size={16} />
              </span>{" "}
              Um momento só seu
            </a>
          </Reveal>
        </div>
        <div className="hero-image">
          <img
            src="/images/hero.jpg"
            alt="Retrato editorial de mulher com cachos naturais, em tons quentes e suaves"
            width="1200"
            height="1800"
            fetchPriority="high"
          />
          <div className="image-caption">
            <span>BELEZA QUE RESPEITA QUEM VOCÊ É.</span>
            <span>01 / ESSÊNCIA</span>
          </div>
          <div className="hero-seal" aria-hidden="true">
            <Sparkles size={23} strokeWidth={1} />
            <span>
              naturalmente
              <br />
              <i>você.</i>
            </span>
          </div>
        </div>
      </section>
      <div className="care-strip">
        <span>
          <Leaf size={21} strokeWidth={1.2} /> Cuidado personalizado
        </span>
        <i />
        <span>
          <Heart size={21} strokeWidth={1.2} /> Beleza com acolhimento
        </span>
        <i />
        <span>
          <Sparkles size={21} strokeWidth={1.2} /> Sua essência em primeiro
          lugar
        </span>
      </div>
    </>
  );
}
