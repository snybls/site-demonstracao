import { useState } from "react";
import {
  Scissors,
  Wind,
  Palette,
  Droplets,
  Flower2,
  Sparkles,
} from "lucide-react";
import { business, currency } from "../config/business";
import { BookingButton } from "../components/Booking";
import Reveal from "../components/Reveal";

const icons = {
  scissors: Scissors,
  wind: Wind,
  palette: Palette,
  droplets: Droplets,
  flower: Flower2,
  sparkles: Sparkles,
};
const filters = ["Todos os cuidados", "Cabelos", "Unhas & beleza"];
export default function Services() {
  const [filter, setFilter] = useState(filters[0]);
  const services = business.services.filter(
    (s) => filter === filters[0] || s.category === filter,
  );
  return (
    <section
      id="servicos"
      className="section services-section"
      aria-labelledby="services-title"
    >
      <div className="container">
        <Reveal className="section-heading">
          <div>
            <p className="eyebrow">NOSSO MENU DE CUIDADOS</p>
            <h2 id="services-title">
              Escolha como quer
              <br />
              <em>se sentir hoje.</em>
            </h2>
          </div>
          <p>
            Da mudança que você deseja ao cuidado
            <br className="hidden sm:block" /> que você merece. Encontre seu
            ritual.
          </p>
        </Reveal>
        <div
          className="service-filters"
          role="group"
          aria-label="Filtrar serviços"
        >
          {filters.map((item) => (
            <button
              key={item}
              aria-pressed={item === filter}
              className={
                item === filter ? "filter-button active" : "filter-button"
              }
              onClick={() => setFilter(item)}
            >
              {item}
            </button>
          ))}
        </div>
        <div className="service-grid" aria-live="polite">
          {services.map((service, index) => {
            const Icon = icons[service.icon as keyof typeof icons];
            return (
              <Reveal
                key={service.id}
                delay={index * 0.035}
                className="service-card"
              >
                <div className="service-top">
                  <Icon size={29} strokeWidth={1} />
                  <span>0{business.services.indexOf(service) + 1}</span>
                </div>
                <h3>{service.name}</h3>
                <p>{service.description}</p>
                <div className="service-bottom">
                  <div>
                    <small>A PARTIR DE</small>
                    <strong>{currency(service.price)}</strong>
                  </div>
                  <BookingButton
                    className="service-booking"
                    service={service.name}
                  >
                    <span>
                      Agendar<span className="sr-only"> {service.name}</span>
                    </span>
                  </BookingButton>
                </div>
              </Reveal>
            );
          })}
        </div>
        <p className="section-note">
          Preços ilustrativos. O valor final varia conforme a avaliação e o
          cuidado escolhido.
        </p>
      </div>
    </section>
  );
}
