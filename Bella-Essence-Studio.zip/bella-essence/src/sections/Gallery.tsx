import { useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Instagram,
  X,
  Expand,
} from "lucide-react";
import Reveal from "../components/Reveal";
import { InstagramButton } from "../components/Booking";

const photos = [
  {
    src: "ondas",
    title: "Movimento & luminosidade",
    category: "COLORAÇÃO E PENTEADOS",
    alt: "Inspiração de coloração: cabelos castanhos longos com ondas e reflexos luminosos",
    width: 900,
    height: 1350,
  },
  {
    src: "corte",
    title: "Um ritual de cuidado",
    category: "TRATAMENTO CAPILAR",
    alt: "Profissional lavando e tratando os cabelos de uma mulher no lavatório do salão",
    width: 800,
    height: 1200,
  },
  {
    src: "unhas",
    title: "Beleza nos detalhes",
    category: "UNHAS & BELEZA",
    alt: "Aplicação cuidadosa de esmalte durante uma manicure",
    width: 700,
    height: 1049,
  },
  {
    src: "beleza",
    title: "Sua beleza, sua identidade",
    category: "CORTES & ESTILO",
    alt: "Retrato editorial de mulher com cabelos pretos lisos",
    width: 800,
    height: 1200,
  },
  {
    src: "studio",
    title: "Espaço para desacelerar",
    category: "ATMOSFERA DO STUDIO",
    alt: "Salão de beleza de inspiração com cadeiras e espelhos em ambiente contemporâneo",
    width: 1200,
    height: 816,
  },
];
export default function Gallery() {
  const [selected, setSelected] = useState(0);
  const dialog = useRef<HTMLDialogElement>(null);
  const current = photos[selected];
  function move(direction: number) {
    setSelected((index) => (index + direction + photos.length) % photos.length);
  }
  return (
    <section
      id="galeria"
      className="section gallery-section container"
      aria-labelledby="gallery-title"
    >
      <Reveal className="section-heading">
        <div>
          <p className="eyebrow">O BELO MORA NOS DETALHES</p>
          <h2 id="gallery-title">
            Inspire-se. <em>Imagine-se.</em>
          </h2>
        </div>
        <InstagramButton>
          <Instagram size={17} /> Nosso universo no Instagram{" "}
          <ArrowUpRight size={16} />
        </InstagramButton>
      </Reveal>
      <div className="gallery-grid">
        {photos.map((photo, index) => (
          <Reveal
            key={photo.src}
            className={`gallery-item gallery-item-${index + 1}`}
            delay={index * 0.03}
          >
            <button
              className="gallery-photo"
              aria-label={`Ampliar: ${photo.title}`}
              aria-haspopup="dialog"
              onClick={() => {
                setSelected(index);
                dialog.current?.showModal();
              }}
            >
              <img
                src={`/images/${photo.src}.jpg`}
                alt={photo.alt}
                width={photo.width}
                height={photo.height}
                loading="lazy"
              />
              <span className="gallery-overlay">
                <span>
                  <small>{photo.category}</small>
                  <strong>{photo.title}</strong>
                </span>
                <Expand size={20} />
              </span>
            </button>
          </Reveal>
        ))}
      </div>
      <p className="section-note">
        Galeria de inspiração com fotografias de banco de imagens. Não
        representa trabalhos realizados pelo studio.
      </p>
      <dialog
        ref={dialog}
        className="lightbox"
        aria-label="Galeria de inspiração ampliada"
        onClick={(event) => {
          if (event.target === event.currentTarget) dialog.current?.close();
        }}
        onKeyDown={(event) => {
          if (event.key === "ArrowLeft") move(-1);
          if (event.key === "ArrowRight") move(1);
        }}
      >
        <button
          className="icon-button lightbox-close"
          aria-label="Fechar imagem"
          onClick={() => dialog.current?.close()}
        >
          <X />
        </button>
        <img
          src={`/images/${current.src}.jpg`}
          alt={current.alt}
          width={current.width}
          height={current.height}
        />
        <div className="lightbox-controls">
          <button
            className="icon-button"
            aria-label="Imagem anterior"
            onClick={() => move(-1)}
          >
            <ArrowLeft />
          </button>
          <p aria-live="polite">
            {current.title}
            <small>
              {selected + 1} de {photos.length} · Fotografia de inspiração
            </small>
          </p>
          <button
            className="icon-button"
            aria-label="Próxima imagem"
            onClick={() => move(1)}
          >
            <ArrowRight />
          </button>
        </div>
      </dialog>
    </section>
  );
}
