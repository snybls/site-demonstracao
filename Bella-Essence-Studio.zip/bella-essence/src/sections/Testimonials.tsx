import { Quote } from "lucide-react";
import Reveal from "../components/Reveal";

const reviews = [
  {
    text: "Um daqueles lugares em que a gente se sente acolhida desde a chegada. Saí com o cabelo lindo e com a autoestima renovada.",
    name: "Mariana A.",
    service: "Corte & finalização",
    initials: "MA",
  },
  {
    text: "Adorei o cuidado em entender o que eu queria. A cor ficou delicada, iluminada e muito mais bonita do que eu imaginava.",
    name: "Camila R.",
    service: "Coloração",
    initials: "CR",
  },
  {
    text: "Ter um momento para mim fez toda a diferença na semana. Atendimento carinhoso e atenção em cada pequeno detalhe.",
    name: "Juliana M.",
    service: "Manicure & pedicure",
    initials: "JM",
  },
];
export default function Testimonials() {
  return (
    <section
      id="depoimentos"
      className="section testimonials-section"
      aria-labelledby="testimonials-title"
    >
      <div className="container">
        <Reveal className="text-center">
          <p className="eyebrow">CUIDADO QUE VIRA BOA MEMÓRIA</p>
          <h2 id="testimonials-title">
            O carinho que <em>fica.</em>
          </h2>
          <p className="testimonial-disclaimer">
            Depoimentos ilustrativos, criados para esta demonstração.
          </p>
        </Reveal>
        <div className="testimonials-grid">
          {reviews.map((review, index) => (
            <Reveal
              key={review.name}
              className="testimonial"
              delay={index * 0.07}
            >
              <Quote size={27} strokeWidth={1} aria-hidden="true" />
              <blockquote>“{review.text}”</blockquote>
              <div className="reviewer">
                <span className="avatar" aria-hidden="true">
                  {review.initials}
                </span>
                <div>
                  <strong>{review.name}</strong>
                  <span>{review.service}</span>
                </div>
                <small>
                  EXEMPLO
                  <br />
                  ILUSTRATIVO
                </small>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
