import { ArrowUpRight, Check } from "lucide-react";
import Reveal from "../components/Reveal";

export default function About() {
  return (
    <section
      id="sobre"
      className="section about container"
      aria-labelledby="about-title"
    >
      <Reveal className="about-visual">
        <img
          src="/images/studio.jpg"
          width="1200"
          height="816"
          alt="Inspiração de ambiente: salão elegante com espelhos amplos e cadeiras confortáveis"
          loading="lazy"
        />
        <div className="about-image-label">
          <span>BELLA ESSENCE</span>
          <i>Um respiro na sua rotina.</i>
        </div>
        <span className="photo-note">
          Imagem de inspiração para o studio fictício.
        </span>
      </Reveal>
      <Reveal className="about-copy">
        <p className="eyebrow">BEM-VINDA AO SEU MOMENTO</p>
        <h2 id="about-title">
          Mais que beleza,
          <br />
          uma <em>experiência.</em>
        </h2>
        <p>
          Acreditamos na beleza que começa quando você se sente bem. Por isso,
          cada detalhe do Bella Essence foi pensado para transformar uma pausa
          na rotina em um encontro com você mesma.
        </p>
        <p>
          Da primeira conversa ao toque final, a proposta é ouvir, acolher e
          cuidar. Um atendimento próximo, que respeita seu estilo e valoriza sua
          beleza de um jeito leve, natural e só seu.
        </p>
        <ul className="about-values">
          <li>
            <Check size={16} /> Escuta atenta e cuidado individual
          </li>
          <li>
            <Check size={16} /> Conforto em cada detalhe
          </li>
          <li>
            <Check size={16} /> Técnica e sensibilidade em harmonia
          </li>
        </ul>
        <a href="#galeria" className="text-link">
          Sinta a atmosfera Bella Essence <ArrowUpRight size={17} />
        </a>
      </Reveal>
    </section>
  );
}
