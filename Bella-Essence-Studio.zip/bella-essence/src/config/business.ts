import settings from "./business.json";
export const business = settings;
export const navigation = [
  ["inicio", "Início"],
  ["sobre", "Sobre"],
  ["servicos", "Serviços"],
  ["galeria", "Galeria"],
  ["depoimentos", "Depoimentos"],
  ["contato", "Contato"],
] as const;
export const currency = (value: number) =>
  new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
    maximumFractionDigits: 0,
  }).format(value);
export function bookingUrl(service?: string) {
  const number = business.whatsapp.replace(/\D/g, "");
  if (business.demo || !/^55\d{10,11}$/.test(number)) return null;
  return `https://wa.me/${number}?text=${encodeURIComponent(`Olá! Gostaria de agendar ${service ? service.toLowerCase() : "um horário"} no ${business.name}.`)}`;
}
