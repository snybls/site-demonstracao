import { createContext, useContext, useRef, useState } from "react";
import type { ReactNode } from "react";
import { ArrowUpRight, MessageCircle, Sparkles, X } from "lucide-react";
import { bookingUrl, business } from "../config/business";

const DemoContext = createContext<
  (service?: string, kind?: "booking" | "instagram") => void
>(() => {});
export function BookingProvider({ children }: { children: ReactNode }) {
  const dialog = useRef<HTMLDialogElement>(null);
  const [content, setContent] = useState({ service: "", kind: "booking" });
  function open(service = "", kind = "booking") {
    setContent({ service, kind });
    dialog.current?.showModal();
  }
  return (
    <DemoContext.Provider value={open}>
      {children}
      <dialog
        ref={dialog}
        className="demo-dialog"
        aria-labelledby="demo-dialog-title"
        onClick={(e) => {
          if (e.target === e.currentTarget) dialog.current?.close();
        }}
      >
        <button
          className="icon-button dialog-close"
          aria-label="Fechar janela"
          onClick={() => dialog.current?.close()}
        >
          <X size={21} />
        </button>
        <Sparkles size={30} strokeWidth={1} className="dialog-symbol" />
        <p className="eyebrow">UMA PRÉVIA DA EXPERIÊNCIA</p>
        <h2 id="demo-dialog-title">
          {content.kind === "instagram"
            ? "Nossa beleza, em breve no seu feed."
            : "Seu momento de cuidado."}
        </h2>
        {content.service && (
          <p className="selected-service">
            Serviço escolhido: <strong>{content.service}</strong>
          </p>
        )}
        <p>
          {content.kind === "instagram"
            ? "O perfil do Instagram ainda não foi configurado."
            : "O agendamento pelo WhatsApp ainda não está disponível nesta demonstração."}{" "}
          Bella Essence Studio é uma empresa fictícia.
        </p>
        <p className="dialog-note">
          {content.kind === "instagram"
            ? "Este botão é ilustrativo e não abre um perfil real."
            : "Nenhuma reserva foi realizada e nenhuma mensagem foi enviada. Em um site real, este botão abrirá a conversa com o salão."}
        </p>
        <button
          className="button button-primary w-full"
          onClick={() => dialog.current?.close()}
        >
          Continuar explorando <ArrowUpRight size={17} />
        </button>
      </dialog>
    </DemoContext.Provider>
  );
}
export function BookingButton({
  children,
  service,
  className = "button button-primary",
  icon = true,
}: {
  children: ReactNode;
  service?: string;
  className?: string;
  icon?: boolean;
}) {
  const open = useContext(DemoContext);
  const url = bookingUrl(service);
  const content = (
    <>
      {children}
      {icon && <ArrowUpRight size={16} aria-hidden="true" />}
    </>
  );
  return url ? (
    <a
      className={className}
      href={url}
      target="_blank"
      rel="noopener noreferrer"
    >
      {content}
    </a>
  ) : (
    <button
      type="button"
      className={className}
      onClick={() => open(service)}
      aria-haspopup="dialog"
    >
      {content}
    </button>
  );
}
export function InstagramButton({
  children,
  className = "text-link",
}: {
  children: ReactNode;
  className?: string;
}) {
  const open = useContext(DemoContext);
  return business.instagram ? (
    <a
      className={className}
      href={business.instagram}
      target="_blank"
      rel="noopener noreferrer"
    >
      {children}
    </a>
  ) : (
    <button
      className={className}
      onClick={() => open("", "instagram")}
      aria-haspopup="dialog"
    >
      {children}
    </button>
  );
}
export function WhatsAppMark() {
  return <MessageCircle size={17} strokeWidth={1.5} aria-hidden="true" />;
}
