import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import Brand from "./Brand";
import { BookingButton } from "./Booking";
import { navigation } from "../config/business";

export default function Header() {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("inicio");
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) =>
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActive(entry.target.id);
        }),
      { rootMargin: "-15% 0px -65% 0px" },
    );
    navigation.forEach(([id]) => {
      const element = document.getElementById(id);
      if (element) observer.observe(element);
    });
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    const close = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", close);
    return () => window.removeEventListener("keydown", close);
  }, []);
  return (
    <>
      <div className="announcement">
        <span>Beleza com propósito. Cuidado com essência.</span>
        <a href="#sobre">
          Conheça o studio <span aria-hidden="true">↗</span>
        </a>
      </div>
      <header className="site-header">
        <div className="nav-shell">
          <Brand />
          <nav
            className={open ? "navigation is-open" : "navigation"}
            id="main-navigation"
            aria-label="Navegação principal"
          >
            {navigation.map(([id, label]) => (
              <a
                key={id}
                href={`#${id}`}
                aria-current={active === id ? "location" : undefined}
                onClick={() => setOpen(false)}
              >
                {label}
              </a>
            ))}
          </nav>
          <div className="nav-actions">
            <BookingButton className="button button-outline header-booking">
              Agendar horário
            </BookingButton>
            <button
              className="icon-button menu-toggle"
              aria-label={open ? "Fechar menu" : "Abrir menu"}
              aria-controls="main-navigation"
              aria-expanded={open}
              onClick={() => setOpen(!open)}
            >
              {open ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </header>
      {open && (
        <button
          className="menu-backdrop"
          tabIndex={-1}
          aria-label="Fechar menu de navegação"
          onClick={() => setOpen(false)}
        />
      )}
    </>
  );
}
