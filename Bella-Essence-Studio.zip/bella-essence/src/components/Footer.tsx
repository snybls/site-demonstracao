import { ArrowUp, Instagram } from "lucide-react";
import Brand from "./Brand";
import { InstagramButton, BookingButton, WhatsAppMark } from "./Booking";
import { business, navigation } from "../config/business";

export default function Footer() {
  return (
    <footer className="site-footer">
      <div className="container">
        <div className="footer-main">
          <div>
            <Brand />
            <p>
              Beleza que acolhe.
              <br />
              Cuidado que revela sua essência.
            </p>
          </div>
          <nav aria-label="Navegação do rodapé">
            {navigation.slice(1).map(([id, label]) => (
              <a href={`#${id}`} key={id}>
                {label}
              </a>
            ))}
          </nav>
          <div className="footer-socials">
            <InstagramButton className="social-button">
              <Instagram size={19} />
              <span className="sr-only">Instagram demonstrativo</span>
            </InstagramButton>
            <BookingButton className="social-button" icon={false}>
              <WhatsAppMark />
              <span className="sr-only">WhatsApp demonstrativo</span>
            </BookingButton>
            <a
              className="social-button back-top"
              href="#inicio"
              aria-label="Voltar ao início"
            >
              <ArrowUp size={18} />
            </a>
          </div>
        </div>
        <div className="footer-bottom">
          <span>
            © {new Date().getFullYear()} {business.name}.
          </span>
          <span>Site demonstrativo — empresa fictícia</span>
          <span>
            Feito para inspirar. <span aria-hidden="true">✧</span>
          </span>
        </div>
      </div>
    </footer>
  );
}
