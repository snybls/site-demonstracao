import { business } from "../config/business";

export function Emblem({ className = "" }: { className?: string }) {
  return (
    <svg
      className={className}
      width="38"
      height="46"
      viewBox="0 0 38 46"
      fill="none"
      aria-hidden="true"
    >
      <path
        d="M19 3C11 12 5 17 5 27a14 14 0 0028 0C33 17 27 12 19 3Z"
        stroke="currentColor"
        strokeWidth=".9"
      />
      <path
        d="M19 14v31M10 24l9 9 9-9M13 18l6 7 6-7"
        stroke="currentColor"
        strokeWidth=".9"
      />
    </svg>
  );
}
export default function Brand() {
  return (
    <a
      href="#inicio"
      className="brand"
      aria-label={`${business.name} — início`}
    >
      <Emblem />
      <span>
        {business.name.replace(/\s+Studio$/i, "")}
        <small>STUDIO · BEAUTY & CARE</small>
      </span>
    </a>
  );
}
