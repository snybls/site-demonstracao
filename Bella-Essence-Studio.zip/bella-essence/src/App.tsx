import Header from "./components/Header";
import Footer from "./components/Footer";
import { BookingProvider } from "./components/Booking";
import Hero from "./sections/Hero";
import About from "./sections/About";
import Services from "./sections/Services";
import Gallery from "./sections/Gallery";
import Testimonials from "./sections/Testimonials";
import Contact, { BookingSection } from "./sections/Contact";

export default function App() {
  return (
    <BookingProvider>
      <a className="skip-link" href="#conteudo">
        Pular para o conteúdo
      </a>
      <Header />
      <main id="conteudo">
        <Hero />
        <About />
        <Services />
        <Gallery />
        <Testimonials />
        <BookingSection />
        <Contact />
      </main>
      <Footer />
    </BookingProvider>
  );
}
