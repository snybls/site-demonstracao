# Verificação da entrega

Data: 19/10/2026. Projeto local, sem publicação ou compra de domínio.

## Correção da abertura por dois cliques

- Adicionada uma segunda compilação, em `demo/index.html`, com React, CSS, fotografias e fontes incorporados em um HTML autônomo.
- O `index.html` principal e o de `dist/` encaminham para a cópia portátil quando o protocolo é `file:`. Por HTTP, o aplicativo Vite mantém o funcionamento normal.
- `npm run build` passou e atualiza as duas versões. Os scripts incorporados também são validados pelo parser de JavaScript após a montagem do HTML.
- Versão autônoma conferida por HTTP local: hero visível, fotografia carregada, zero arquivos externos de scripts ou estilos e fotos com URLs `data:`.
- Filtros, diálogo de agendamento, galeria ampliada, próxima imagem e fechamento por Escape testados nessa versão.
- A abertura literal por `file://` não pôde ser automatizada porque a política do navegador integrado bloqueia esse protocolo. Não foi contornado esse bloqueio; a mesma página autônoma foi testada por HTTP local.

## Build e dependências

- Dependências instaladas com npm; `package-lock.json` incluído.
- `npm run build`: aprovado. Inclui a checagem estrita de TypeScript.
- Dev server Vite executado e resposta HTTP 200 confirmada.
- Build de produção servido por `npm run preview` e testado no navegador.
- JS de produção: aproximadamente 120 kB gzip; CSS: aproximadamente 8 kB gzip.
- Fotografias locais: aproximadamente 0,8 MB no total. Fontes hospedadas localmente.

## Navegador

| Verificação | Resultado |
| --- | --- |
| Desktop, larguras de 1101 e 1440 px | Layout inspecionado visualmente |
| Celular de 390 px | Hero, menu, serviços, galeria e contato inspecionados |
| Celular de 320 px | Verificação de largura: conteúdo 305 px / área útil 305 px; sem overflow |
| Tablet de 768 px | Conteúdo 753 px / área útil 753 px; sem overflow |
| Navegação por seção | Destinos existentes, links testados e indicação da seção |
| Menu de celular | Abre e fecha; fecha ao selecionar uma seção |
| Filtro Todos os cuidados | 6 serviços |
| Filtro Cabelos | 4 serviços |
| Filtro Unhas & beleza | 2 serviços |
| Agendamento por serviço | Diálogo identifica o serviço escolhido e informa que não há reserva real |
| Diálogo e teclado | Escape fecha; foco retorna ao botão que abriu |
| Galeria | Amplia, navega por botões e setas do teclado e fecha por Escape |
| Instagram vazio | Explicação demonstrativa, sem perfil de terceiros |
| Fotografias | Todas carregadas, `naturalWidth > 0`; sem imagem quebrada |
| Links internos | Nenhuma âncora sem destino |
| Console da produção | Sem erros ou avisos na navegação verificada |
| Semântica | Idioma pt-BR, um h1, títulos hierárquicos e nomes acessíveis nos controles |

O tamanho útil desconta a barra de rolagem reservada pelo navegador. Uma sobra horizontal detectada em 320 px foi corrigida antes do build final. Durante o desenvolvimento, um import de fonte foi corrigido; a validação acima corresponde ao build final de produção.

## Honestidade e acessibilidade

- Nome fictício e aviso de demonstração no rodapé.
- Depoimentos identificados como ilustrativos, sem estrelas, notas ou selos de verificação inventados.
- Preços e horários apresentados como exemplos.
- Número de WhatsApp, Instagram, e-mail e mapa real vazios no arquivo central.
- Sem envio de mensagens, pagamentos, autenticação, banco ou coleta de dados.
- Fotos identificadas como inspiração; não são apresentadas como portfólio real.
- Textos alternativos e dimensões das imagens conferidos.
- Navegação e diálogos acessíveis pelo teclado; link para pular ao conteúdo.
- `prefers-reduced-motion` tratado pelo CSS e pelo hook do Framer Motion. Revisão do código; sem simulação dessa preferência no navegador.

## SEO e implantação

- Metatags de título, descrição e Open Graph conferidas no HTML gerado.
- Sem URL canonical inventada; sitemap vazio e válido enquanto não houver domínio.
- `robots.txt` e meta robots desativam indexação da demonstração.
- Geração de canonical, Open Graph com URL e sitemap testada em cópia isolada com o domínio reservado `salon.example`; a entrega continua sem domínio configurado.
- Netlify: build, diretório de saída, fallback de SPA e cabeçalhos incluídos.
- README com instalação, personalização, domínio .com.br e publicação.

Não foram realizados deploy, medição Lighthouse, auditoria WCAG completa nem testes em aparelhos físicos ou navegadores adicionais. Os testes responsivos usam o navegador integrado em dimensões controladas.
